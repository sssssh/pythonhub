This file provides a minor mode for inserting docstring skeleton
for Python functions and methods.  The structure of the docstring is
as per the requirements of the Sphinx documentation generator
<http://sphinx-doc.org/index.html>
